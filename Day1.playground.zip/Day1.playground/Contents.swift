import UIKit
//These are the notes I took

//Variables section
var s = "humphrey"

//Strings and integers section
var p = 70
var str = "hello"

//Multi-line strings section
var multi = """
This is
a multi-line
string
"""// """ are required for multi-line strings

//Doubles and Booleans section
var pi = 3.1415
var bool = true

//String interpolation section
var number = 60
var number_str = "Your number was \(number)" //backslash(variable)

//Constants section
let ape = "monke" //now this cannot be changed

//Type annotations section
let num: Int = 45
let str1: String = "hello"
let double: Double = 4.423
let bool1: Bool = false
//let name: type of variable = ....

//Arrays section
let person1 = "john"
let person2 = "perry the platypus"
let person3 = "dr doofenshmirtz"
let person4 = "katy perry"
let array = [person1, person2, person3, person4]
array[3] //exactly like Java except without ;

//sets section
let say = Set(["dog", "cat", "kitten"]) //array but unorganized
let say2 = Set(["dog", "cat", "dog"]) //doesn't take repeats
//can't access with numerical positions since organized randomly

//tuples section
var name = (first: "Perry", last: "the Platypus")
name.0 //can call using numbers or name of the word
name.first

//dictionary section
let heights = [
    "Taylor Swift": 1.78,
    "Ed Sheeran": 1.73
]
heights["Taylor Swift"] //returns 1.78

let favoriteIceCream = [
    "Paul": "Chocolate",
    "Sophie": "Vanilla"
]
favoriteIceCream["Paul"] //returns chocolate
favoriteIceCream["Charlotte", default: "Unknown"] //returns unknown instead of nil

//enum section
enum Result {
    case success
    case failure
}
let result = Result.failure //stops from mispelling or using different strings to define one outcome

//enum associate value section
enum Activity{
    case bored
    case running (destination: String)
    case talking (topic: String)
    case singing (volume: Int)
}
let talking = Activity.talking(topic: "football") //more specific version of talking

//enum raw values section
enum Planet: Int{
    case mercury = 1 //changes this variables count to "1" instead of starting at 0
    case venus
    case earth
    case mars
}
let earth = Planet(rawValue: 2) //assigns "earth" to the earth variable

//for loop section
let count = 1...10
for number in count{
    print("Number is \(number)")
}

let albums = ["Red", "1989", "Reputation"]
for albums in albums {
    print("\(albums) is on apple music")
}

print("Players gonna ")
for _ in 1...5 {
    print("play")
}

//while loop section
var num1 = 1
while num1 <= 20{
    print(num1)
    num1 += 1
}
print("Ready or not, here I come")

//repeat loop section
var num2 = 1
repeat {
    print(number)
    number += 1
} while number <= 20
print ("ready or not, here I come")

//break section
var countdown = 10
while countdown >= 0{
    print(countdown)
    if countdown == 4{
        print("I'm bored. lets go now")
        break
    }
    countdown -= 1
}

//break multiple loops
outerLoop: for i in 1...10{
    for j in i...10{
        let product = i * j
        print("\(i) * \(j) is \(product)")
        
        if product == 50 {
            print("its a bullseye")
            break outerLoop
        }
    }
}

//skipping items
for i in 1...10 {
    if i % 2 == 1{
        continue
    }
}

//infinite loops
var count1 = 0
while true {
    print(" ")
    count1 += 1
    
    if count1 == 273{
        break
    }
}

//function
func printHelp() {
    let message = "hello"
    print(message)
}
printHelp()

//func parameter
func square(number: Int){
    print(number*number)
}
square(number: 8)

//return
func square1(number1: Int) -> Int{
    return number * number
}
print(square1(number1: 8))

//parameter labels
func sayHello(to name: String){
    print("Hello, \(name)")
}
sayHello(to: "taylor")

//after this point, I talked to Angela, and she let me know that I just had to watch the videos...
